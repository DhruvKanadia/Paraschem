/**
 * Write product value in lowercase and label will be in Title Case
 */

export const ProductOptions = [
  {
    "label": "ACETIC ACID",
    "value": "acetic acid"
  },
  {
    "label": "AMMONIUM MOLYBDATE",
    "value": "ammonium molybdate"
  },
  {
    "label": "AMMONIUM SULPHATE(TECHNICAL)",
    "value": "ammonium sulphate(technical)"
  },
  {
    "label": "ANHYDROUS SODIUM SULPHATE (28331100)",
    "value": "anhydrous sodium sulphate (28331100)"
  },
  {
    "label": "ANHYDROUS SODIUM SULPHATE (28331990)",
    "value": "anhydrous sodium sulphate (28331990)"
  },
  {
    "label": "AOS",
    "value": "aos"
  },
  {
    "label": "BLEACHING POWDER",
    "value": "bleaching powder"
  },
  {
    "label": "CALCIUM CARBONATE",
    "value": "calcium carbonate"
  },
  {
    "label": "CALCIUM CHLORIDE",
    "value": "calcium chloride"
  },
  {
    "label": "CAPB",
    "value": "capb"
  },
  {
    "label": "CAUSTIC POTASH FLAKES",
    "value": "caustic potash flakes"
  },
  {
    "label": "CAUSTIC SODA FLAKES",
    "value": "caustic soda flakes"
  },
  {
    "label": "CAUSTIC SODA LYE",
    "value": "caustic soda lye"
  },
  {
    "label": "CAUSTIC SODA PRILLS",
    "value": "caustic soda prills"
  },
  {
    "label": "CDEA",
    "value": "cdea"
  },
  {
    "label": "CITRIC ACID ANHYDROUS",
    "value": "citric acid anhydrous"
  },
  {
    "label": "CITRIC ACID MONOHYDRATE",
    "value": "citric acid monohydrate"
  },
  {
    "label": "DOLAMITE POWDER ECO-ACID",
    "value": "dolamite powder eco-acid"
  },
  {
    "label": "ETHYL ACETATE",
    "value": "ethyl acetate"
  },
  {
    "label": "FORMIC ACID",
    "value": "formic acid"
  },
  {
    "label": "GLYCERINE",
    "value": "glycerine"
  },
  {
    "label": "HYDRATED LIME POWDER",
    "value": "hydrated lime powder"
  },
  {
    "label": "HYDROGEN PEROXIDE",
    "value": "hydrogen peroxide"
  },
  {
    "label": "ISO PROPYL ALCOHOL (IPA)",
    "value": "iso propyl alcohol (ipa)"
  },
  {
    "label": "KEYBOARD/MOUSE 84716040",
    "value": "keyboard/mouse 84716040"
  },
  {
    "label": "LABSA(ACID SLURRY)",
    "value": "labsa(acid slurry)"
  },
  {
    "label": "MAGNESIUM CHLORIDE FLAKES",
    "value": "magnesium chloride flakes"
  },
  {
    "label": "MAGNESIUM SULPHATE",
    "value": "magnesium sulphate"
  },
  {
    "label": "MEG",
    "value": "meg"
  },
  {
    "label": "MEGA WHITE 2BA",
    "value": "mega white 2ba"
  },
  {
    "label": "MEGAWHITE HI (CRBX)",
    "value": "megawhite hi (crbx)"
  },
  {
    "label": "MEGAWHITE-2B",
    "value": "megawhite-2b"
  },
  {
    "label": "MINERAL POWDER",
    "value": "mineral powder"
  },
  {
    "label": "MOBILE",
    "value": "mobile"
  },
  {
    "label": "OXALIC ACID",
    "value": "oxalic acid"
  },
  {
    "label": "PHOSPHORIC ACID",
    "value": "phosphoric acid"
  },
  {
    "label": "POLY ALUMINIUM CHLORIDE (PAC)",
    "value": "poly aluminium chloride (pac)"
  },
  {
    "label": "POLYACRYLAMIDE ACCOFLOC G-04",
    "value": "polyacrylamide accofloc g-04"
  },
  {
    "label": "POTASSIUM HYDROXIDE PELLETS",
    "value": "potassium hydroxide pellets"
  },
  {
    "label": "POTASSIUM PERMANGANATE",
    "value": "potassium permanganate"
  },
  {
    "label": "ROSBA 2B SPL POWDER",
    "value": "rosba 2b spl powder"
  },
  {
    "label": "SALT",
    "value": "salt"
  },
  {
    "label": "SLES L-24-230",
    "value": "sles l-24-230"
  },
  {
    "label": "SODA ASH",
    "value": "soda ash"
  },
  {
    "label": "SODIUM ACEATE",
    "value": "sodium aceate"
  },
  {
    "label": "SODIUM BENZOATE",
    "value": "sodium benzoate"
  },
  {
    "label": "SODIUM BI CARBONATE",
    "value": "sodium bi carbonate"
  },
  {
    "label": "SODIUM HYDRO SULPHIDE",
    "value": "sodium hydro sulphide"
  },
  {
    "label": "SODIUM HYDROXIDE PELLETS",
    "value": "sodium hydroxide pellets"
  },
  {
    "label": "SODIUM HYPOCHLORITE",
    "value": "sodium hypochlorite"
  },
  {
    "label": "SODIUM META BI SULPHITE",
    "value": "sodium meta bi sulphite"
  },
  {
    "label": "SODIUM SULPHIDE FLAKES",
    "value": "sodium sulphide flakes"
  },
  {
    "label": "SODIUM SULPHIDE LIQUID",
    "value": "sodium sulphide liquid"
  },
  {
    "label": "SODIUM THIO SULPHATE",
    "value": "sodium thio sulphate"
  },
  {
    "label": "STEARIC ACID (DISTRIC)",
    "value": "stearic acid (distric)"
  },
  {
    "label": "SULFAMIC ACID",
    "value": "sulfamic acid"
  },
  {
    "label": "SULPHER BLACK",
    "value": "sulpher black"
  },
  {
    "label": "SULPHONATED CASTOR OIL (TRO)",
    "value": "sulphonated castor oil (tro)"
  },
  {
    "label": "TECHNICAL GRADE UREA",
    "value": "technical grade urea"
  },
  {
    "label": "TRI SODIUM PHOSPHATE",
    "value": "tri sodium phosphate"
  }
]