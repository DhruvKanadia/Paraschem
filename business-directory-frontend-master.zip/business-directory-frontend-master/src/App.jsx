import { Container } from "@chakra-ui/react"
import { createBrowserRouter, createRoutesFromElements, Outlet, Route, RouterProvider } from "react-router-dom"
import './App.css'
import { AddClient } from "./pages/AddClient"
import ErrorPage from './pages/error-page.jsx'
import Home from './pages/Home'
import { Login } from "./pages/Login.Page"
import { ProductResult } from "./pages/ProductResult"
import { getClient, ViewClient } from "./pages/ViewClient"
import instance from "./utils/axiosInstance"
import useToken from "./utils/useToken"
import {AddProductPage} from './pages/AddProduct'
import { ClientResult } from "./pages/ClientResult"

const Root = () => {
  return (
    <Outlet />
  )
}

const router = createBrowserRouter(
  createRoutesFromElements(
    <Route path='/' element={<Root />} errorElement={<ErrorPage />} >
      <Route index element={<Home />} />
      <Route path='/search' element={<ProductResult />} />
      <Route path='/addClient' element={<AddClient />} />
      <Route path='/view/:id' element={<ViewClient />} loader={getClient} />
      <Route path='/addProduct' element={<AddProductPage />} />
      <Route path='/updateClient' element={<ClientResult />} />
      {/* <Route path='login' element={} /> */}
    </Route>
  )
)


function App() {
  const { token, setToken } = useToken()

  const handleLogoutBtn = async () => {
    try {
      let result = await instance.post('/auth/logout')
      // console.log(result)
      console.log('Logged out successfully')
      window.location.href = '/'
      setToken({})
    } catch (error) {
      console.log('error while logging out')
      console.log(error)
    }

  }

  if (!token) {
    return <Login setToken={setToken} />
  }
  document.title = 'Paras Chem India'
  return (
    <>
    
    <RouterProvider router={router} />
      <Container centerContent margin='1rem auto' color='gray.600' textDecoration='underline' as='button' onClick={handleLogoutBtn} >logout</Container>
      </>
  )
}

export default App
