import React, { useState } from 'react'
import { Button, HStack, Input, InputGroup, InputLeftAddon, InputRightAddon } from '@chakra-ui/react'
import { useNavigate, } from 'react-router-dom'
import {HamburgerMenu} from '../utils/HamburgerMenu'
export const ClientSearchBar = () => {
    let [clientName, setClientName] = useState('')
    let navigate = useNavigate()

    let enterKeyHandler = (e) => {
        if (e.key === 'Enter') {
            e.preventDefault()
            // console.log('enter key');
            searchClientByName()
            // return;
        } else { return; }
        // console.log('inside navigatae');
    }
    const searchClientByName = () => {
        navigate("/updateClient?name=" + clientName.toLowerCase())

    }
    return (
        <HStack m="2em auto" width={[360, 560, 720]}>
            <InputGroup>
            <InputLeftAddon
             children={<HamburgerMenu/>} 
            p={0}
            />
                <Input
                onChange={(e) => { setClientName(e.target.value) }}
                onKeyUp={enterKeyHandler}
                border={'1px solid #E2E8F0'}
                focusBorderColor='gray.300'
                placeholder='Search by client name'
                />
                <InputRightAddon
                    padding='0'
                    borderTopEndRadius={16}
                    borderBottomEndRadius={16}
                    children={<Button
                        borderTopStartRadius={0}
                        borderBottomStartRadius={0}
                        borderTopEndRadius={16}
                        borderBottomEndRadius={16}
                        type='submit'
                        onClick={searchClientByName}
                    >
                        Search
                    </Button>} />
            </InputGroup>
        </HStack>
    )
}