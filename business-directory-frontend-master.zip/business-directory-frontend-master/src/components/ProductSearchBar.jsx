import React, { useState } from 'react'
import { Button, FormControl, HStack, Input, InputGroup, InputLeftAddon, InputRightAddon } from '@chakra-ui/react'
import { SearchIcon } from '@chakra-ui/icons'
import { useNavigate, } from 'react-router-dom'
import Select, { createFilter } from 'react-select'
import { ProductOptions } from '../data/ProductOptions'
import CustomOption from '../utils/CustomOption'
import CustomMenuList from '../utils/CustomMenuList'

export const StaticSearchBar = () => {
    let [Product, setProduct] = useState('')
    let navigate = useNavigate()

    let enterKeyHandler = (e) => {
        if (e.key === 'Enter') {
            e.preventDefault()
            // console.log('enter key');
            searchProduct()
            // return;
        } else { return; }
        // console.log('inside navigatae');
    }
    const searchProduct = () => {
        navigate("/search?product=" + Product.toLowerCase())

    }
    return (
        <HStack m="2em auto" width={[360, 560, 720]}>
            <InputGroup>
                <InputLeftAddon
                    children={<SearchIcon />}
                    borderTopStartRadius={16}
                    borderBottomStartRadius={16} />
                {/* <Input
                // focusBorderColor={'gray.300'}
                _focusVisible={false}
                    // borderRadius={4}
                    placeholder='Search product name'
                    onChange={(e) => { setProduct(e.target.value) }}
                    onKeyUp={enterKeyHandler}
                    
                /> */}
                <Select
                    captureMenuScroll={false}
                    classNamePrefix="custom-select"
                    components={{ Option: CustomOption, MenuList: CustomMenuList }}
                    filterOption={createFilter({ ignoreAccents: false, })}
                    options={ProductOptions}
                    styles={{
                        container: (baseStyles, state) => ({
                            ...baseStyles,
                            width: '-webkit-fill-available',
                            borderRadius: '0px',
                            boxShadow: 'none',
                        }),
                        control: (baseStyles, state) => ({
                            ...baseStyles,
                            borderColor: '#E2E8F0',
                            borderRadius: '0px',
                            boxShadow: 'none',
                            ":hover": ({
                                borderColor: '#E2E8F0',
                                boxShadow: 'none',
                            })
                        }),
                        input: (baseStyles, state) => ({
                            ...baseStyles,
                            height: '1.85rem'
                        }),
                        menuPortal: (baseStyles, state) => ({
                            ...baseStyles,
                            zIndex: 2,
                            border: '1px solid red'
                        })
                    }}
                    placeholder='Enter product name'
                    onChange={(e) => { setProduct(e.value) }}
                // onKeyDown={enterKeyHandler}

                />
                <InputRightAddon
                    padding='0'
                    borderTopEndRadius={16}
                    borderBottomEndRadius={16}
                    children={<Button
                        borderTopStartRadius={0}
                        borderBottomStartRadius={0}
                        borderTopEndRadius={16}
                        borderBottomEndRadius={16}
                        type='submit'
                        onClick={searchProduct}
                    >
                        Search
                    </Button>} />
            </InputGroup>
        </HStack>
    )
}