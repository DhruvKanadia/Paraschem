import { Button, Text, Container, Input, FormControl, FormLabel, Heading } from '@chakra-ui/react'
import PropTypes from 'prop-types'
import axios from 'axios'
import { useState } from 'react'
import instance from '../utils/axiosInstance'


const LoginComponent = ({ setToken }) => {
    const [errorMessage, setErrorMessage] = useState('')
    const [isLoading, setIsLoading] = useState(false)

    const loginUser = async (credentials) => {
        //TODO change during production
        let result
        try {
            result = await instance.post('/auth', credentials)
            // console.log(JSON.stringify(result))
            setToken(result.data)
            // console.log(result.data.accessToken)
            // return result
        } catch (err) {
            if (err?.response.status == 401) {
                setErrorMessage(err.response.data.message)
            } else
             if(err){
                console.log('error other than login credentials')
                console.log(err)
            }
            // console.log('error handled successfully')
        } finally {
            setIsLoading(false)
        }
    }

    const handleLoginSubmit = async (e) => {
        e.preventDefault()
        setIsLoading(true)
        // Read the form data
        const form = e.target;
        let formData = new FormData(form)
        formData = Object.fromEntries(formData.entries())

        loginUser(formData)

    }

    return (
        <Container rowGap={4} m={'3rem auto'} width={['sm', null, null, 'lg']} border='1px solid #FC7300' p={8} borderRadius={12} >
            <Text color='red'>{errorMessage}</Text>
            <br />
            <Heading as='h3' color='gray.700'>Login to Continue</Heading>
            <br />
            <form method="post" onSubmit={handleLoginSubmit} autoComplete='off' >
                <FormControl>
                    <FormLabel>Username</FormLabel>
                    <Input placeholder='Username' type='text' name='username' />
                </FormControl>
                <br />
                <FormControl>
                    <FormLabel>Password</FormLabel>
                    <Input placeholder='Password' type='password' name='password' />
                </FormControl>
                <br />
                <Button isLoading={isLoading} type="submit" variant='solid'>Login</Button>
            </form>
        </Container>
    )


}
LoginComponent.propTypes = {
    setToken: PropTypes.func.isRequired
}

export { LoginComponent }