import React, { useState } from 'react'
import { Button, HStack, InputGroup, InputRightAddon, } from '@chakra-ui/react'
import { useNavigate, } from 'react-router-dom'
import { createFilter } from 'react-select'
import AsyncSelect from 'react-select/async'
import { ProductOptions } from '../data/ProductOptions'
import CustomOption from '../utils/CustomOption'
import CustomMenuList from '../utils/CustomMenuList'
import { getProductsFromBackend } from '../utils/getProductsFromBackend'
import {HamburgerMenu} from '../utils/HamburgerMenu'

export const AsyncSearchBar = () => {
    let navigate = useNavigate()
    let [Product, setProduct] = useState('')

    const searchProduct = () => {
        navigate("/search?product=" + Product.toLowerCase())
    }

    return (
        <HStack m="2em auto" width={[360, 560, 720]}>
<HamburgerMenu />
            <InputGroup>
                {/*  <InputLeftAddon
                    children={<SearchIcon />}
                    borderTopStartRadius={16}
                    borderBottomStartRadius={16} /> */}
                <AsyncSelect
                    //attributes specific for async fetching from db
                    cacheOptions
                    defaultOptions={ProductOptions}
                    loadOptions={getProductsFromBackend}
                    // onInputChange={(e) => setQuery(e)}
                    onChange={(e) => { setProduct(e.value) }}
                    captureMenuScroll={false}
                    classNamePrefix="custom-select"
                    components={{ Option: CustomOption, MenuList: CustomMenuList }}
                    filterOption={createFilter({
                        ignoreAccents: false,
                        // matchFrom: 'start'
                    })}
                    // options={ProductOptions}
                    styles={{
                        container: (baseStyles, state) => ({
                            ...baseStyles,
                            width: '-webkit-fill-available',
                            borderRadius: '0px',
                            boxShadow: 'none',
                        }),
                        control: (baseStyles, state) => ({
                            ...baseStyles,
                            borderColor: '#E2E8F0',
                            borderRadius: '0px',
                            boxShadow: 'none',
                            ":hover": ({
                                borderColor: '#E2E8F0',
                                boxShadow: 'none',
                            })
                        }),
                        input: (baseStyles, state) => ({
                            ...baseStyles,
                            height: '1.85rem'
                        }),

                    }}
                    placeholder='Product name'
                // onKeyDown={enterKeyHandler}

                />
                <InputRightAddon
                    padding='0'
                    borderTopEndRadius={16}
                    borderBottomEndRadius={16}
                    children={<Button
                        borderTopStartRadius={0}
                        borderBottomStartRadius={0}
                        borderTopEndRadius={16}
                        borderBottomEndRadius={16}
                        type='submit'
                        onClick={searchProduct}
                    >
                        Search
                    </Button>} />
            </InputGroup>
        </HStack>
    )
}