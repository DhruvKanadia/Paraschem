import { EditIcon, EmailIcon, ViewIcon } from '@chakra-ui/icons';
import { HStack, Tooltip } from '@chakra-ui/react'

export let clientColumns = [
    {
        name: 'Company',
        wrap: true,
        selector: row => row.name,

    },
    {
        name: 'Phone 1',
        cell: row => <span onClick={() => window.open(`tel:${row.phone[0]}`, '_self')} style={{ cursor: 'pointer', borderBottom: '1px solid gray', }} >{row.phone[0]}</span>,
        wrap: true,
    },
    {
        name: 'GSTIN',
        selector: row => row.gst,
        // selector: row => row.phone[1],
        wrap: true,

    },
    {
        name: 'Action',
        cell: (row) => (
            <HStack spacing={4}>
                <Tooltip label={row.email[0]} bg='gray.200' color='black' placement={'top'} shadow='sm' fontSize='md' >
                    <EmailIcon onClick={(e) => {
                        window.open(`mailto:${row.email[0]}`, '_blank', 'noreferrer')
                        e.preventDefault()
                    }} cursor='pointer' boxSize={5} />
                </Tooltip>
                <Tooltip label='Update Client' bg='gray.200' color='black.600' placement={'top'} shadow='sm' fontSize='sm' >
                    <EditIcon as={'button'} onClick={
                        () => window.open(`/view/${row._id}`, '_blank')
                    } cursor='pointer' boxSize={5} />
                </Tooltip>
                {/* <EditIcon as={'button'} onClick={() => console.log('inside email')} cursor='pointer' boxSize={5} /> */}
            </HStack>),
        right: true,
    }
]