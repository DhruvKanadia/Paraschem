import React from 'react'
import { Menu, MenuButton, MenuList, MenuItem, IconButton, Icon } from '@chakra-ui/react'
import { HamburgerIcon, PlusSquareIcon, RepeatIcon } from '@chakra-ui/icons'
import { useNavigate, } from 'react-router-dom'
import {HiOutlineHome} from 'react-icons/hi'
import {AiOutlineUserAdd} from 'react-icons/ai'
export const HamburgerMenu = () => {
    let navigate = useNavigate()
    return (
        <>
            <Menu>
                <MenuButton
                    as={IconButton}
                    icon={<HamburgerIcon />}
                    variant='outline'
                />
                <MenuList
                border='1px dashed black'
                >
                    <MenuItem 
                    onClick={() => navigate('/')} 
                    icon = {<Icon as={HiOutlineHome}/>}
                    >
                        Home
                    </MenuItem>
                    <MenuItem 
                    icon={<Icon as={AiOutlineUserAdd}/>}
                    onClick={() => navigate('/addClient')}
                    >
                        New Client
                    </MenuItem>
                    <MenuItem
                        icon={<PlusSquareIcon />}
                        onClick={() => navigate('/addProduct')}>
                        New Product
                    </MenuItem>
                    <MenuItem
                        onClick={() => navigate('/updateClient')}
                        icon = {<RepeatIcon />}
                        >
                        Update Client
                    </MenuItem>
                </MenuList>
            </Menu>
        </>
    )
}