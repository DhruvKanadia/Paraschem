import instance from "./axiosInstance"


const getProductsFromBackend = async (query) => {
    // query database only when query length matches condition
    if (query.length >= 2) {
        let res = await instance.get('api/product/match?value=' + query)
        return res.data.data
    }
}

export { getProductsFromBackend }