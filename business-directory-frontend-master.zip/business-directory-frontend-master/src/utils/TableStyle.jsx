export const customStyles = {
    rows: {
      style: {
        minHeight: '54px', // override the row height
        fontWeight: 'medium',
        fontSize: '14px',
      },
    },
    headRows: {
      style: {
        fontSize: '16px',
      },
    },
    headCells: {
      style: {
        // border:'1px solid tomato',
        padding: '0.5em', // override the cell padding for head cells
        fontSize: '16px',
        fontWeight: 'bold',
        color: '#4A5568',
      },
    },
    cells: {
      style: {
        padding: '0 0.5em', // override the cell padding for data cells
        // paddingRight: '18px',
        color: '#2D3748',
      },
    },
  }
