import { EditIcon, EmailIcon, ViewIcon } from '@chakra-ui/icons';
import { HStack, Tooltip } from '@chakra-ui/react'

export let columns = [
    {
        name: 'Company',
        wrap: true,
        selector: row => row.name,

    },
    {
        name: 'Phone 1',
        cell: row => <span onClick={()=>window.open(`tel:${row.phone[0]}`,'_self')} style={{cursor:'pointer', borderBottom: '1px solid gray',}} >{row.phone[0]}</span> ,
        wrap: true,
    },
    {
        name: 'Phone 2',
        cell: row => <span onClick={()=>window.open(`tel:${row.phone[1]}`,'_self')} style={{cursor:'pointer', borderBottom: '1px solid gray',}} >{row.phone[1]}</span> ,
        // selector: row => row.phone[1],
        wrap: true,
        
    },
    {
        name: 'Action',
        cell: (row) => (
            <HStack spacing={4}>
                <Tooltip label={row.email[0]} bg='transparent' color='black' placement={'top'} shadow='sm' fontSize='md' >
                    <EmailIcon onClick={(e) => { 
                        window.open(`mailto:${row.email[0]}`, '_blank', 'noreferrer') 
                        e.preventDefault()
                        }} cursor='pointer' boxSize={5} />
                </Tooltip>
                <ViewIcon as={'button'} onClick={
                    () => window.open(`/view/${row._id}`, '_blank')
                    } cursor='pointer' boxSize={5} />
                {/* <EditIcon as={'button'} onClick={() => console.log('inside email')} cursor='pointer' boxSize={5} /> */}
            </HStack>),
        right: true,
    }
]