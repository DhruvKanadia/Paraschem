import { LoginComponent } from "../components/Login";

export const Login = ({setToken}) => {
    document.title = 'User Login'
    return (
        <LoginComponent setToken={setToken} />
    )
}
