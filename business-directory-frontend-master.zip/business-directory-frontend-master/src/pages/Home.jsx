import { Flex, Box } from "@chakra-ui/react"
import { useNavigate } from "react-router"
import { AsyncSearchBar } from "../components/AsyncSearch"

const Home = () => {
    let navigate = useNavigate()
    const redirectTo = (path) => {
        navigate(path)
    }
    
    return (
        <Flex direction={'column'} justify='center' gap={4} >
            <AsyncSearchBar />
            <Flex wrap={"wrap"} gap={4} justify='center'  >
            <Box as='button'  border='1px solid ' boxSize='xs' onClick={()=>redirectTo('/addClient')}>
                Add New Client
            </Box>
            <Box as='button' border='1px solid ' boxSize='xs' onClick={()=>redirectTo('/addProduct')}>
                Add New Product
            </Box>
            <Box as='button' border='1px solid ' boxSize='xs' onClick={()=>redirectTo('/updateClient')}>
                Update Client Information
            </Box>
            </Flex>
        </Flex>
    )
}

export default Home