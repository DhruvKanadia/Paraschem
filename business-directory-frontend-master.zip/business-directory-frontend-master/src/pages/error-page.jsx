import { Heading, Text, VStack, Image } from "@chakra-ui/react";
import React from "react";
import { Link } from "react-router-dom";
import notFound from '../assets/page_not_found.svg'

const error = () => {
    return (
        <VStack margin={8} spacing={4}>
            <Image src={notFound} boxSize="xs" />
            <Heading as="h1" >
                Error 404! Page Not found.
            </Heading>
            <Text>
                Please recheck the URL. Or visit the <Link to="/" style={{ color:'tomato',}} >Home Page</Link>
            </Text>
        </VStack>
    )
}

export default error