import {
    Flex, FormControl,
    FormLabel,
    Input, Heading, Button, ButtonGroup, Box, useToast
} from '@chakra-ui/react'
import { AsyncSearchBar } from '../components/AsyncSearch'

import instance from '../utils/axiosInstance'

const AddProductPage = () => {
    document.title = 'Add New Product'
    const toast = useToast()

    const handleProductAdd = async (e) => {
        e.preventDefault()
        // console.log('inside product add handler')
        let products = document.getElementsByName('productField')
        // console.log(products[0].value)
        let productName = products[0].value
        try {
            let response = await instance.post('/api/product/create', { value: productName })
            toast({
                title: response.data.message,
                description: response.data.data.label,
                status: 'success',
                duration: 2000,
                isClosable: true,
                position: 'top-right'
            })
        } catch (err) {
            console.log('Error while adding new product.')
            console.log(err)
            toast({
                title: 'Product creation failed.',
                description: err.response.data.data,
                status: 'error',
                duration: 2000,
                isClosable: true,
                position: 'top-right'
            })
        }
    }
    return (
        <>
            <AsyncSearchBar />
            <form onSubmit={handleProductAdd} method="post" name='productForm '>
                <Flex direction='column' w={['xs', null, 'lg']} m='0.5rem auto' gap={4} color='#332C39'>
                    <FormControl>
                        <FormLabel >Product Name</FormLabel>
                        <Input type='text' name='productField' />
                    </FormControl>
                    <ButtonGroup maxW='sm' margin={'0 auto'}>
                        <Button type='submit' variant='solid'>Save</Button>
                        <Button type='reset' variant='ghost'>Reset</Button>
                    </ButtonGroup>

                </Flex>
            </form>
        </>
    )
}

export { AddProductPage }