import React, { useEffect, useState } from 'react'
import DataTable from 'react-data-table-component'
import { Box, Flex, Heading } from '@chakra-ui/react'
import { useSearchParams } from 'react-router-dom';
import { BeatLoader } from 'react-spinners';

import { customStyles } from '../utils/TableStyle';
import { columns } from '../utils/ColumnStruct';
import instance from '../utils/axiosInstance';
import { AsyncSearchBar } from '../components/AsyncSearch';


const ProductResult = () => {
    let [params,] = useSearchParams()
    const [buyResult, setBuyResult] = useState()
    const [sellResult, setSellResult] = useState()
    const [isLoading, setIsLoading] = useState(true)
    let productName = params.get('product')
    // console.log(import.meta.env.VITE_API);
    // console.log('product url change to - '+productName)

    const findBuyingFromAPI = async () => {
        try {
            let res = await instance.get("/api/client/buy?product=" + productName)
            // console.log('buy data fetched')
            setBuyResult(res.data.data)
            // console.log(res.data.data)
        } catch (err) {
            console.log(err.message);
        }
    }
    const findSellingFromAPI = async () => {
        try {
            let res = await instance.get("/api/client/sell?product=" + productName)
            // console.log('sell data fetched')
            setSellResult(res.data.data)
            // console.log( res.data.data)
        } catch (err) {
            console.log(err.message);
        }
    }

    const getProductData = async () => {
        setIsLoading(true)
        await Promise.all([
            findBuyingFromAPI(),
            findSellingFromAPI()

        ])
        setIsLoading(false)
        // console.log('loaing false')
    }

    function titleCase(str) {
        return str.toLowerCase().split(' ').map(function(word) {
          return word.replace(word[0], word[0].toUpperCase());
        }).join(' ');
      }

    useEffect(
        () => {
            getProductData()
            document.title = titleCase(productName) + ' - Results'
        }
        , [productName]
    )

    return (
        <>
            {
                // isLoading ?
                // <Container>

                // <BeatLoader
                //         color={'#6096B4'}
                //         margin='2rem auto'
                //         size='2rem'
                //         />
                //         </Container>   
                //     :
                <>
                    <AsyncSearchBar />
                    <Flex flexDirection='column' >
                        <Heading as='h1' padding={4} >Buying From</Heading>
                        <Box
                            // boxSize={'lg'}
                            margin={4}
                            border='1px solid #FC7300'
                            boxShadow='md'
                            p='4'
                            borderRadius={8} >
                            <DataTable
                                columns={columns}
                                data={buyResult}
                                customStyles={customStyles}
                                keyField='_id'
                                //TODO decide following features
                                highlightOnHover={true}
                                striped={true}
                                persistTableHead={true}
                                progressPending={isLoading}
                                progressComponent={<BeatLoader
                                    color='#FC7300'
                                    cssOverride={{
                                        margin: '1rem auto',
                                    }}
                                />}
                            />
                        </Box>
                    </Flex>
                    <Flex flexDirection='column' >
                        <Heading as='h1' padding={4} >Selling To</Heading>
                        <Box
                            margin={4}
                            border='1px solid #FC7300'
                            boxShadow='md'
                            p='4'
                            borderRadius={8} >

                            <DataTable
                                columns={columns}
                                data={sellResult}
                                customStyles={customStyles}
                                keyField='_id'
                                highlightOnHover={true}
                                striped={true}
                                persistTableHead={true}
                                progressPending={isLoading}
                                progressComponent={<BeatLoader
                                    color='#FC7300'
                                    cssOverride={{
                                        margin: '1rem auto'
                                    }} />}
                            // noDataComponent={<ErrorPage/>}
                            />
                        </Box>
                    </Flex>
                </>
            }
        </>
    )
}

export { ProductResult }
