import {
    Flex, FormControl,
    FormLabel,
    Input, Heading, Button, ButtonGroup, Box, useToast
} from '@chakra-ui/react'
import { useState } from 'react'
import AsyncSelect from 'react-select/async';

import { ProductOptions } from '../data/ProductOptions';
import instance from '../utils/axiosInstance';
import { AsyncSearchBar } from '../components/AsyncSearch';
import { getProductsFromBackend } from '../utils/getProductsFromBackend';

export const AddClient = () => {
    document.title = 'Add New Client'

    const [selectedBuyOption, setBuySelectedOption] = useState([]);
    const [selectedSellOption, setSellSelectedOption] = useState([]);
    const toast = useToast()
    const [isLoading, setIsLoading] = useState(false)

    const handleBuyListChange = (options) => {
        setBuySelectedOption(options)
        // console.log(selectedOption)
        // console.log(typeof(options))
    }
    const handleSellListChange = (options) => {
        setSellSelectedOption(options)
        // console.log(selectedOption)
        // console.log(typeof(options))
    }

    let phoneInputCount = 3, emailInputCount = 3

    const handleFormSubmit = async (e) => {
        e.preventDefault();
        setIsLoading(true)
        // Read the form data
        const form = e.target;
        let formData = new FormData(form)
        formData = Object.fromEntries(formData.entries())

        //filter phone number inputs to single array and then save it to object
        let phoneArr = []
        for (let i = 0; i < phoneInputCount; i++) {

            let phoneInput = `phone[${i}]`
            let x = document.forms['myForm'][phoneInput].value
            delete formData[phoneInput]
            if (x !== '') {
                phoneArr.push(x)
            }
        }
        formData.phone = phoneArr

        //filter email-id inputs to single array and then save it to object
        let emailArr = []
        for (let i = 0; i < emailInputCount; i++) {

            let emailInput = `email[${i}]`
            let y = document.forms['myForm'][emailInput].value
            delete formData[emailInput]
            if (y !== '') {
                emailArr.push(y)
            }
        }
        formData.email = emailArr


        let buyProducts = []
        selectedBuyOption.forEach(
            (val) => {
                buyProducts.push(val.value)
            }
        )
        formData.buy = buyProducts

        let sellProducts = []
        selectedSellOption.forEach(
            (val) => {
                sellProducts.push(val.value)
            }
        )
        formData.sell = sellProducts

        delete formData['colors']
        delete formData['colors2']
        // console.log(formData)


        // for (const [key, value] of formData.entries()) {
        // console.log('formdata\n'+formData.entries())
        // }
        // console.log(typeof (formData))
        try {
            //TODO format data for api
            let response = await instance.post(
                '/api/client/create',
                formData
            )
            // console.log(response)
            toast({
                title: response.data.name,
                description: response.data.message,
                status: 'success',
                duration: 2000,
                isClosable: true,
            })
            setIsLoading(false)
        }
        catch (err) {
            toast({
                title: 'Client creation failed.',
                description: err.response.data.data,
                status: 'error',
                duration: 2000,
                isClosable: true,
            })
            console.log(err)
        }
    }

    return (
        <>
            <AsyncSearchBar />
            <form method='POST' onSubmit={handleFormSubmit} name='myForm'>
                <Flex direction={'column'} gap={4} color='#332C39'>
                    <Heading margin={'1rem 0 0 2rem'} as='h1'>Add New Client Information</Heading>
                    <Flex direction={['column', null, 'row']} gap={8} margin={'0 3rem'}>
                        <FormControl>
                            <FormLabel>Company Name</FormLabel>
                            <Input type='text' name='name' />
                        </FormControl>
                        <FormControl>
                            <FormLabel>Company GSTIN</FormLabel>
                            <Input type='text' name='gst' />
                        </FormControl>


                    </Flex>
                    <Flex direction={['column', null, 'row']} gap={8} margin={'0 3rem'}>
                        <FormControl>
                            <FormLabel>Phone Number-1</FormLabel>
                            <Input type='text' name='phone[0]' />
                        </FormControl>
                        <FormControl>
                            <FormLabel>Phone Number-2</FormLabel>
                            <Input type='number' name='phone[1]' />
                        </FormControl>
                        <FormControl>
                            <FormLabel>Phone Number-3</FormLabel>
                            <Input type='number' name='phone[2]' />
                        </FormControl>

                        {/* // TODO add option to add more phone numbers dynamically
    <Box as={'button'} bg='gray.200' maxWidth={'24rem'} alignSelf='center' maxHeight={'40px'} p={4} noOfLines={1} borderRadius={4} >Add Phone Number</Box> */}
                    </Flex>
                    <Flex direction={['column', null, 'row']} gap={8} margin={'0 3rem'}>
                        <FormControl>
                            <FormLabel>Email address-1</FormLabel>
                            <Input type='email' name='email[0]' />
                        </FormControl>
                        <FormControl>
                            <FormLabel>Email address-2</FormLabel>
                            <Input type='email' name='email[1]' />
                        </FormControl>
                        <FormControl>
                            <FormLabel>Email address-3</FormLabel>
                            <Input type='email' name='email[2]' />
                        </FormControl>
                    </Flex>
                    <Flex direction={['column', null, 'row']} gap={8} margin={'0 3rem'}>
                        <Box w={['xs', null, 'md']}>
                            <FormLabel htmlFor='colors'>Buying Products</FormLabel>
                            <AsyncSelect
                                cacheOptions
                                defaultOptions={ProductOptions}
                                loadOptions={getProductsFromBackend}
                                styles={{
                                    container: (baseStyles, _state) => ({
                                        ...baseStyles,
                                        width: '-webkit-fill-available'
                                    })
                                }}
                                closeMenuOnSelect={false}
                                isMulti
                                name="colors"
                                // options={ProductOptions}
                                onChange={handleBuyListChange}
                                escapeClearsValue={true}
                            /></Box>
                        <Box w={['xs', null, 'md']}>
                            <FormLabel htmlFor='colors2'>Selling Products</FormLabel>

                            <AsyncSelect
                                cacheOptions
                                defaultOptions={ProductOptions}
                                loadOptions={getProductsFromBackend}
                                styles={{
                                    container: (baseStyles, _state) => ({
                                        ...baseStyles,
                                        width: '-webkit-fill-available'
                                    })
                                }}
                                closeMenuOnSelect={false}
                                isMulti
                                name="colors2"
                                onChange={handleSellListChange}
                                escapeClearsValue={true} /></Box>
                    </Flex>
                    <ButtonGroup maxW='sm' margin={'0 0 2rem 3rem'}>
                        <Button type='submit' isLoading={isLoading} variant='solid'>Save</Button>
                        <Button type='reset' variant='ghost'>Reset</Button>
                    </ButtonGroup>
                </Flex>
            </form>
        </>
    )
}