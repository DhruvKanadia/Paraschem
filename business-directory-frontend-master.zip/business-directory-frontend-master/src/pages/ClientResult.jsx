import React, { useEffect, useState } from 'react'
import DataTable from 'react-data-table-component'
import { Box, Flex, Heading } from '@chakra-ui/react'
import { useSearchParams } from 'react-router-dom';
import { BeatLoader } from 'react-spinners';

import { customStyles } from '../utils/TableStyle';
import { clientColumns as columns } from '../utils/ClientColumnStruct';
import instance from '../utils/axiosInstance';
import { ClientSearchBar } from '../components/ClientSearchBar';


const ClientResult = () => {
    let [params,] = useSearchParams()
    const [clientResult, setClientResult] = useState()
    // const [sellResult, setSellResult] = useState()
    const [isLoading, setIsLoading] = useState(true)
    let clientNameSearch = params.get('name')
    // console.log(import.meta.env.VITE_API);
    // console.log('product url change to - '+productName)

    const findAllClientByName = async () => {
        try {
            let res = await instance.get("/api/client/all?name=" + clientNameSearch)
            // console.log('sell data fetched')
            setClientResult(res.data.data)
            // console.log( res.data.data)
        } catch (err) {
            console.log(err.message);
        }
    }

    const getProductData = async () => {
        setIsLoading(true)
        await Promise.all([
            findAllClientByName()

        ])
        setIsLoading(false)
        // console.log('loaing false')
    }

    function titleCase(str) {
        return str.toLowerCase().split(' ').map(function(word) {
          return word.replace(word[0], word[0].toUpperCase());
        }).join(' ');
      }

    useEffect(
        () => {
            getProductData()
            document.title ='Update Client'
        }
        , [clientNameSearch]
    )

    return (
        <>
            {
                // isLoading ?
                // <Container>

                // <BeatLoader
                //         color={'#6096B4'}
                //         margin='2rem auto'
                //         size='2rem'
                //         />
                //         </Container>   
                //     :
                <>
                    <ClientSearchBar />
                    <Flex flexDirection='column' >
                        <Heading as='h1' padding={4} >Matched Clients</Heading>
                        <Box
                            // boxSize={'lg'}
                            margin={4}
                            border='1px solid #FC7300'
                            boxShadow='md'
                            p='4'
                            borderRadius={8} >
                            <DataTable
                                columns={columns}
                                data={clientResult}
                                customStyles={customStyles}
                                keyField='_id'
                                //TODO decide following features
                                highlightOnHover={true}
                                striped={true}
                                persistTableHead={true}
                                progressPending={isLoading}
                                progressComponent={<BeatLoader
                                    color='#FC7300'
                                    cssOverride={{
                                        margin: '1rem auto',
                                    }}
                                />}
                            />
                        </Box>
                    </Flex>
                </>
            }
        </>
    )
}

export { ClientResult }
