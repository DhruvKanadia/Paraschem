import {
    Flex, FormControl,
    FormLabel,
    Input, Heading, Button, ButtonGroup, Box, useToast, useDisclosure,
    Modal,
    ModalOverlay,
    ModalContent,
    ModalHeader,
    ModalFooter,
    ModalBody,
    ModalCloseButton
} from '@chakra-ui/react'
import { useLoaderData } from "react-router"
import { useState, useRef, useEffect } from 'react'
import AsyncSelect from 'react-select/async'

import { ProductOptions } from '../data/ProductOptions';
import { EditIcon, DeleteIcon } from '@chakra-ui/icons';
import instance from '../utils/axiosInstance';
import { AsyncSearchBar } from '../components/AsyncSearch';
import { getProductsFromBackend } from '../utils/getProductsFromBackend'

const ViewClient = () => {
    const dataFromLoader = useLoaderData()
    document.title = dataFromLoader.data.name + ' - Information'

    // console.log('dataFromLoader buy')
    // console.log(dataFromLoader)

    //hooks
    const { isOpen, onOpen, onClose } = useDisclosure()
    const [selectedBuyOption, setBuySelectedOption] = useState([]);
    const [selectedSellOption, setSellSelectedOption] = useState([]);
    const buyProductsRef = useRef()
    const sellProductsRef = useRef()
    const toast = useToast()
    const [isReadOnly, setIsReadOnly] = useState(true)
    const [isDeleting, setIsDeleting] = useState(false)
    // const [isSaving, setIsSaving] = useState(false)

    useEffect(() => {
        buyProductsRef.current.setValue(dataFromLoader.data.buy)
        sellProductsRef.current.setValue(dataFromLoader.data.sell)
        // console.log('set value trigered');
    }, []
    )

    /**
 * Fuction to store buying products in an array
 * 
 */
    const handleBuyListChange = (options) => {
        setBuySelectedOption(options)
        // console.log(selectedOption)
        // console.log(typeof(options))
    }
    const handleSellListChange = (options) => {
        setSellSelectedOption(options)
        // console.log(selectedOption)
        // console.log(typeof(options))
    }

    const handleDeleteBtn = async () => {
        // console.log('delete id')
        // console.log() 
        let id = document.getElementsByName('_id')[0].value
        setIsDeleting(!isDeleting)
        try {
            await instance.get('/api/client/delete/' + id)
            toast({
                title: 'Client deleted successfully.',
                description: "We've deleted client from directory.",
                status: 'success',
                duration: 2000,
                isClosable: true,
                position: 'top'
            })
            setIsDeleting(!isDeleting)
            setTimeout(() => {
                window.location.href = '/'
            }, 3000);
        } catch (err) {
            console.log(err.message)
        }
    }

    /**
     * Handle update form submit request
     * 
     */
    const handleFormSubmit = async (e) => {
        e.preventDefault();
        setIsDeleting(!isDeleting)

        //FIXME number of phone and email fields --nothing to fix just a flag
        let phoneInputCount = 3, emailInputCount = 3

        // Read the form data
        const form = e.target;
        let formData = new FormData(form)
        formData = Object.fromEntries(formData.entries())
console.log(formData);
        //filter phone number inputs to single array and then save it to object
        let phoneArr = []
        for (let i = 0; i < phoneInputCount; i++) {

            let phoneInput = `phone[${i}]`
            let x = document.forms['myForm'][phoneInput].value
            delete formData[phoneInput]
            if (x !== '') {
                phoneArr.push(x)
            }
        }
        formData.phone = phoneArr

        //filter email-id inputs to single array and then save it to object
        let emailArr = []
        for (let i = 0; i < emailInputCount; i++) {

            let emailInput = `email[${i}]`
            let y = document.forms['myForm'][emailInput].value
            delete formData[emailInput]
            if (y !== '') {
                emailArr.push(y)
            }
        }
        formData.email = emailArr


        let buyProducts = []
        selectedBuyOption.forEach(
            (val) => {
                buyProducts.push(val.value)
            }
        )
        formData.buy = buyProducts

        let sellProducts = []
        selectedSellOption.forEach(
            (val) => {
                sellProducts.push(val.value)
            }
        )
        formData.sell = sellProducts

        delete formData['colors']
        delete formData['colors2']
        // delete formData['_id']
        // console.log('updatead data')
        // console.log(formData)


        // for (const [key, value] of formData.entries()) {
        // console.log('formdata\n'+formData.entries())
        // }
        // console.log(typeof (formData))
        try {
            //TODO format data for api
            await instance.post(
                '/api/client/update',
                formData
            )
            // console.log(response)
            toast({
                title: 'Client data updated.',
                description: "We've updated client into directory.",
                status: 'success',
                duration: 1500,
                isClosable: true,
                position: 'top'
            })
            // console.log('set is saving done')
            setIsReadOnly(!isReadOnly)
        }
        catch (err) {
            toast({
                title: 'Client updation failed.',
                description: err.response.data.data,
                status: 'error',
                duration: 2000,
                isClosable: true,
                position: 'top'
            })
            console.log(err)
        }
        setIsDeleting(false)
    }

    return (
        <>
            <AsyncSearchBar />
            <form method='POST' name='myForm' onSubmit={handleFormSubmit} >
                <fieldset disabled={isReadOnly} style={{ minWidth: 0, opacity: 1, }} >
                    <Flex direction={'column'} gap={2} color='#332C39' opacity='1' >
                        <Heading margin={'1rem 0 0 2rem'} as='h1'> {isReadOnly ? '' : 'Update'} Client Information</Heading>
                        <Flex direction={['column', null, 'row']} gap={4} margin={'0 3rem'}>
                            <FormControl>
                                <FormLabel>Company Name</FormLabel>
                                <Input
                                    type='text'
                                    name='name'
                                    defaultValue={dataFromLoader.data.name}
                                />
                            </FormControl>
                            <FormControl>
                                <FormLabel>Company GSTIN</FormLabel>
                                <Input type='text' name='gst' defaultValue={dataFromLoader.data.gst} readOnly/>
                            </FormControl>
                            <Input type='hidden' name='_id' defaultValue={dataFromLoader.data._id} />

                        </Flex>
                        <Flex direction={['column', null, 'row']} gap={4} margin={'0 3rem'}>
                            <FormControl>
                                <FormLabel>Phone Number-1</FormLabel>
                                <Input type='text' name='phone[0]' defaultValue={dataFromLoader.data.phone[0]} />
                            </FormControl>
                            <FormControl>
                                <FormLabel>Phone Number-2</FormLabel>
                                <Input type='number' name='phone[1]' defaultValue={dataFromLoader.data.phone[1]} />
                            </FormControl>
                            <FormControl>
                                <FormLabel>Phone Number-3</FormLabel>
                                <Input type='number' name='phone[2]' defaultValue={dataFromLoader.data.phone[2]} />
                            </FormControl>

                            {/* // TODO add option to add more phone numbers dynamically
                        <Box as={'button'} bg='gray.200' maxWidth={'24rem'} alignSelf='center' maxHeight={'40px'} p={4} noOfLines={1} borderRadius={4} >Add Phone Number</Box> */}
                        </Flex>
                        <Flex direction={['column', null, 'row']} gap={4} margin={'0 3rem'}>
                            <FormControl>
                                <FormLabel>Email address-1</FormLabel>
                                <Input type='email' name='email[0]' defaultValue={dataFromLoader.data.email[0]} />
                            </FormControl>
                            <FormControl>
                                <FormLabel>Email address-2</FormLabel>
                                <Input type='email' name='email[1]' defaultValue={dataFromLoader.data.email[1]} />
                            </FormControl>
                            <FormControl>
                                <FormLabel>Email address-3</FormLabel>
                                <Input type='email' name='email[2]' defaultValue={dataFromLoader.data.email[2]} />
                            </FormControl>
                        </Flex>
                        <Flex direction={['column', null, 'row']} gap={8} margin={'0 3rem'}>
                            <Box w={['xs', null, 'md']} >
                                <FormLabel htmlFor='colors'>Buying Products</FormLabel>
                                <AsyncSelect
                                cacheOptions
                                defaultOptions={ProductOptions}
                                loadOptions={getProductsFromBackend}
                                    styles={{
                                        container: (baseStyles, state) => ({
                                            ...baseStyles,
                                            width: '-webkit-fill-available'
                                        })
                                    }}
                                    closeMenuOnSelect={false}
                                    isMulti
                                    name="colors"
                                    // defaultValue={dataFromLoader.data.buy}
                                    ref={buyProductsRef}
                                    onChange={handleBuyListChange}
                                    escapeClearsValue={true}
                                    isDisabled={isReadOnly}
                                /></Box>
                            <Box w={['xs', null, 'md']}>
                                <FormLabel htmlFor='colors2'>Selling Products</FormLabel>

                                <AsyncSelect
                                cacheOptions
                                defaultOptions={ProductOptions}
                                loadOptions={getProductsFromBackend}
                                    styles={{
                                        container: (baseStyles, state) => ({
                                            ...baseStyles,
                                            width: '-webkit-fill-available'
                                        })
                                    }}
                                    ref={sellProductsRef}
                                    closeMenuOnSelect={false}
                                    isMulti
                                    name="colors2"
                                    // defaultValue={dataFromLoader.data.sell}
                                    isDisabled={isReadOnly}
                                    onChange={handleSellListChange}
                                /></Box>
                        </Flex>
                        <ButtonGroup maxW='sm' margin={'0 0 2rem 3rem'}>

                            <Button type='submit' variant='solid' colorScheme='green' isLoading={isDeleting} >Save</Button>
                            {/* <Button type='reset' variant='ghost' >Reset</Button> */}
                        </ButtonGroup>
                    </Flex>
                </fieldset>
            </form>
            <ButtonGroup m={'0.5rem 0 2rem 3rem'} isDisabled={!isReadOnly}>
                <Button type='button' variant='outline'
                    width='24'
                    colorScheme='blue'
                    leftIcon={<EditIcon />}

                    onClick={() => {
                        //  e.preventDefault()
                        // console.log(e)
                        setIsReadOnly(!isReadOnly)
                    }}

                >
                    Edit
                </Button>
                <Button
                    type='button'
                    colorScheme='red'
                    variant='ghost'
                    leftIcon={<DeleteIcon />}
                    onClick={onOpen}
                >

                    Delete
                </Button>
                <Modal isOpen={isOpen} onClose={onClose}>
                    <ModalOverlay />
                    <ModalContent>
                        <ModalHeader>Confirm Delete</ModalHeader>
                        <ModalCloseButton />
                        <ModalBody>
                            Are you sure you want to delete this client data? <br />
                            <b>The data cannot be recovered.</b>
                        </ModalBody>

                        <ModalFooter>
                            <Button
                                colorScheme='red'
                                leftIcon={<DeleteIcon />}
                                mr={3}
                                variant='outline'
                                onClick={handleDeleteBtn}
                                isLoading={isDeleting}
                            >
                                Confirm
                            </Button>
                            <Button variant='solid' onClick={onClose}>Cancel</Button>
                        </ModalFooter>
                    </ModalContent>
                </Modal>
            </ButtonGroup>
        </>
    )
}



/**
 * react-router-dom load data before page render 
 */
const getClient = async ({ params }) => {



    let clientId = params.id
    try {
        const result = await instance.get('/api/client/get/' + clientId)

        result.data.data.buy = formatProducts(result.data.data.buy)
        result.data.data.sell = formatProducts(result.data.data.sell)
        // console.log(result)
        return result.data;
    } catch (err) {
        console.log(err.message)
    }
}

const formatProducts = (prodArr) => {

    const resultArr = []
    prodArr.forEach(item => {
        resultArr.push({ value: item, label: titleCase(item) })
    })
    return resultArr

    function titleCase(str) {
        return str.toUpperCase()
        
        /* return str.toLowerCase().split(' ').map(function (word) {
            return (word.charAt(0).toUpperCase() + word.slice(1));
        }).join(' '); */
    }

}

export { ViewClient, getClient }