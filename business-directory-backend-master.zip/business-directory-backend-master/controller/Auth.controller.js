const bcrypt = require('bcrypt')
const jwt = require('jsonwebtoken')
const asyncHandler = require('express-async-handler')
const LoginSchema = require('../models/Login.Schema')



const login = asyncHandler(async (req, res) => {
    const { username, password } = req.body
    if (!username || !password) {
        return res.status(400).json({ message: 'All fields are required' })
    }

    const foundLogin = await LoginSchema.findOne({ username }).exec()
    if (!foundLogin) {
        return res.status(401).json({ message: 'Username does not exist' })
    }
    const match = await bcrypt.compare(password, foundLogin.password)
    if (!match) {
        return res.status(401).json({ message: 'Invalid Password' })
    }
    const accessToken = jwt.sign(
        {
            'UserInfo': {
                'username': foundLogin.username
            }
        },
        process.env.ACCESS_TOKEN_SECRET,
        { expiresIn: '60m' }
    )

    const refreshToken = jwt.sign(
        {
            'username': foundLogin.username
        },
        process.env.REFRESH_TOKEN_SECRET,
        { expiresIn: '3d' }
    )

    res.cookie('jwt', refreshToken, {
        httpOnly: true,
        secure: true, //https only
        sameSite: 'none',
        maxAge: 7 * 24 * 60 * 60 * 1000,
    }
    )
    res.json({ accessToken })
})

const refresh = (req, res) => {
    const cookies = req.cookies
    // console.log('cookies')
    // console.log(req.cookies)
    if (!cookies?.jwt) {
        return res.status(403).json({ message: 'Unauthorised' })
    }
    const refreshToken = cookies.jwt

    jwt.verify(
        refreshToken,
        process.env.REFRESH_TOKEN_SECRET,
        asyncHandler(async (err, decoded) => {
            if (err) {
                // console.log(err)
                // console.log(req)
                return res.status(403).json({ message: 'Forbidden' })
            }
            const foundLogin = await LoginSchema.findOne({ username: decoded.username })
            if (!foundLogin) return res.status(401).json({ message: 'Username is invalid' })

            const accessToken = jwt.sign(
                {
                    'UserInfo': {
                        'username': foundLogin.username
                    }
                },
                process.env.ACCESS_TOKEN_SECRET,
                { expiresIn: '60m' }
            )

            res.json({ accessToken })
        })
    )
}

const logout = (req, res) => {
    try {
        const cookies = req.cookies
        if (!cookies?.jwt) {
            return res.status(204)
        }
        res.clearCookie('jwt', {
            httpOnly: true,
            sameSite: 'None',
            secure: true
        })
        res.json({ message: 'Cookie cleared.' })
    } catch (err) {
        console.log(err)
    }
}

module.exports = {
    login,
    refresh,
    logout
}