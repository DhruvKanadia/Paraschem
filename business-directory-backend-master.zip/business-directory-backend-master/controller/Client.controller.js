const clientModel = require("../models").clientSchema
const apiResponse = require("../helpers");

const handlerError = (res, err) => {
    if (err) {
        return apiResponse.validationErrorWithData(res, "Validation Error", err);
    }
    return apiResponse.ErrorResponse(res, "Internal Server Error");
};

createClient = async (req, res) => {
    // try {
    let data = req.body
    // console.log(data)
    let clientExists = await clientModel.findOne({ gst: data.gst });
    // console.log("Here is the error: ", uniqueCustomer);
    if (clientExists) {
        return apiResponse.successResponseWithData(res, "Customer already exists!", clientExists);
    }

    let Client = new clientModel({ ...(data) });
    await Client.save()
        .then((customerRef) => {
            return apiResponse.successResponseWithData(
                res,
                "New customer created sucessfully.",
                customerRef
            );
        })
        .catch(err => {
            console.log(err);
            return handlerError(res, err.message)
        })

    /*   }
      catch (err) {
          console.log("Some errs occured while fetching the Error: ", err);
          return handlerError(res, err);
      } */
}

updateClient = async (req, res) => {
    let data = req.body
    // console.log(data)
    await clientModel.findOneAndUpdate({ gst: data.gst }, data, { new: true, runValidators: true })
        .then(updatedClient => {
            return apiResponse.successResponseWithData(
                res,
                "Customer updated sucessfully.",
                updatedClient
            );
        })
        .catch(err => {
            // console.log(err);
            return handlerError(res, err.message)
        })

    /* let clientExists = await client.findOne({ gstin: data.gstin });
    if(clientExists){
    } */
}

getClient = async (req, res) => {
    let _id = req.params.id
    await clientModel.findById(_id).exec().then(data => {
        apiResponse.successResponseWithData(
            res,
            "Success",
            data
        )
        // console.log("data\n"+data);
    }).catch(err => {
        // console.log(err);
        handlerError(res, err.message)
    })
}

deleteClient = async (req, res) => {
    let _id = req.params.id
    await clientModel.deleteOne({ _id: _id }).then(data => {
        // console.log(data);
        apiResponse.successResponseWithData(
            res,
            "Delete Success",
            data
        )
        // console.log("data\n"+data);
    })
        .catch(err => {
            // console.log(err);
            handlerError(res, err.message)
        })
}

searchClientBuyProd = async (req, res) => {
    let productName = req.query.product;
    await clientModel.find(
        { buy: productName },
        // return fields
        ['name', 'phone', 'email'],
    )
        .slice('phone', 1)
        .slice('email', 1)
        .exec()
        .then(data => {
            // console.log(data);
            apiResponse.successResponseWithData(
                res,
                "Find Success",
                data
            )
            // console.log("data\n"+data);
        })
        .catch(err => {
            // console.log(err);
            handlerError(res, err.message)
        })
}

searchClientSellProd = async (req, res) => {
    let productName = req.query.product;
    await clientModel.find(
        { sell: productName },
        // return fields
        ['name', 'phone', 'email'],
    )
        // no.of phone/email
        .slice('phone', 2)
        .slice('email', 1)
        .exec()
        .then(data => {
            // console.log(data);
            apiResponse.successResponseWithData(
                res,
                "Find Success",
                data
            )
            // console.log("data\n"+data);
        })
        .catch(err => {
            // console.log(err);
            handlerError(res, err.message)
        })
}


module.exports = {
    createClient,
    updateClient,
    getClient,
    deleteClient,
    searchClientBuyProd,
    searchClientSellProd
}