const express = require("express");
const clientRouter = require("./Client.route")


const app = express()


app.use("/client",clientRouter)

module.exports = app