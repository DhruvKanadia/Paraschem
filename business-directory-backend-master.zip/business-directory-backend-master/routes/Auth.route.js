const express = require("express");
const authController = require("../controller/Auth.controller");
const limiter = require("../middleware/loginLimiter");

let router = express.Router();

router.route('/')
    .post(limiter, authController.login)

router.route('/refresh' )
    .get(authController.refresh)

router.route('/logout' )
    .post(authController.logout)


module.exports = router