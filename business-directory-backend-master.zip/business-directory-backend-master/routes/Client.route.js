const express = require("express");
const clientController = require("../controller/Client.controller");
const verifyJWT = require("../middleware/verifyJWT");

let router = express.Router();

router.use(verifyJWT)

router.post("/create", clientController.createClient)
router.post("/update", clientController.updateClient)
router.get("/get/:id", clientController.getClient)
router.get("/delete/:id", clientController.deleteClient)
router.get("/buy", clientController.searchClientBuyProd)
router.get("/sell/", clientController.searchClientSellProd)


module.exports = router;