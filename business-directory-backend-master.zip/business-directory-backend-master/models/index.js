const clientSchema = require("./Client.schema")

module.exports = {
    clientSchema,
}