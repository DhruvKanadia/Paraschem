const mongoose = require("mongoose")
const { isMobilePhone, isEmail } = require("validator")

const clientSchema = new mongoose.Schema({
    name: {
        type: String,
        // required: true,
    },
    phone: [{
        type: String,
        // required: true,
        // minlength: 10,
        validate: {
            validator: isMobilePhone,
            message: "Mobile number invalid",
        }
    }],
    email: [{
        type: String,
        lowercase: true,
        validate: {
            validator: isEmail,
            message: "Email address invalid."
        },
        trim: true,
    }],
    gst: String,
    buy: [String],
    sell: [String],
})

module.exports = new mongoose.model("client", clientSchema)
