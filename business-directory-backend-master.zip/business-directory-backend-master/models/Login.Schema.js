const mongoose = require("mongoose")

const loginSchema = new mongoose.Schema({
    username:{
        type: String,
    },
password:{
    type:String,
}
})

module.exports = new mongoose.model('login-info', loginSchema)