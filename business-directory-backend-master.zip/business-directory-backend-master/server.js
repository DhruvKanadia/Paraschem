const express = require("express")
const app = express()
require("dotenv").config();
const cors = require("cors");
const bodyParser = require("body-parser");
const morgan = require('morgan')
const cookieParser = require('cookie-parser')

const authRouter = require('./routes/Auth.route')
const db = require("./db").db_conn
const apiResponse = require("./helpers")
const apiRouter = require("./routes")
const PORT = process.env.PORT || 5000;

// connect to database
db.connectToDb()

app.use(morgan('short'));
app.use(express.json());
// app.use(morgan("dev"));
// parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: false }))
app.use(cookieParser())
// parse application/json
app.use(bodyParser.json())
//To allow cross-origin requests
// console.log(process.env.ALLOWED_ORIGIN.split(', '))
const allowedOrigins = process.env.ALLOWED_ORIGIN.split(', ')

app.use((req, res, next) => {
    origin = req.header('origin')
    console.log(origin, 'origin')
    if (allowedOrigins.includes(origin)) {
        res.setHeader('Access-Control-Allow-Origin', origin);
        console.log('options header set')
    }
    // res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept, Authorization");
    // res.header("Access-Control-Allow-Credentials", true);
    // res.header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, UPDATE");
    next();
})

// console.log(allowedOrigins)
// app.use(cors())
app.use(cors({
    origin: allowedOrigins,
    methods: ['GET', 'PUT', 'POST', 'DELETE', 'UPDATE'],
    allowedHeaders: ['Origin, Content-Type', 'Authorization', 'x-csrf-token','X-Requested-With', 'Content-Type', 'Accept'],
    // maxAge: 600,
    credentials: true,
    exposedHeaders: ['*', 'Authorisation']
}));


//Route Prefixes
app.use('/auth', authRouter)
app.use("/api", apiRouter);


app.get("/ping", (_req, res) => {
    return res.send({
        status: "Server is up and running",
    });
});
// throw 404 if URL not found
app.all("*", function (req, res) {
    return apiResponse.notFoundResponse(res, "Page not found");
});

//------not working if enabled
/*app.use((err, _req, res) => {
    if (err.name == "UnauthorizedError") {
        return apiResponse.unauthorizedResponse(res, err.message);
    }
});*/

app.listen(PORT, () => {
    console.log("Server started listening on port:", PORT);
});