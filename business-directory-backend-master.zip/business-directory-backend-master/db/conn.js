const mongoose = require("mongoose");
const Db = process.env.ATLAS_URL;
mongoose.set('strictQuery', true);
var _db;

module.exports = {
    connectToDb: async () => {
        _db = await mongoose.connect(Db, {
            useNewUrlParser: true,
            useUnifiedTopology: true,
        })
            .then(() => {
                console.log("Database connection Success!");
            })
            .catch(err => {
                console.error("Mongoose Connection Error", err);
            })
    },

    getDb: () => {
        if (_db) {
            return _db;
        }
    },
}
